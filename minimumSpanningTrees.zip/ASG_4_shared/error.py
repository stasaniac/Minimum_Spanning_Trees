from typing import List, Tuple


class Timeout(Exception):
    def __init__(self, time_limit, exec_time):
        super().__init__(f"Execution took {round(exec_time,4)}s, "
                         f"expected {time_limit}s")


class NoOutput(Exception):
    def __init__(self):
        super().__init__("Function did not return anything. "
                         "Did you return your result?")


class WrongType(Exception):
    def __init__(self, type):
        super().__init__("Function returned wrong type. "
                         f"Expected type: {type}")


class WongSize(Exception):
    def __init__(self, expected: int, got: int):
        super().__init__(f"Function returned {got}/{expected} answers.")


class WrongAnswerTask1(Exception):
    def __init__(self, output_l: List[Tuple[int, int]],
                 answer_l: List[Tuple[int, int]]):
        msg = ''
        if len(output_l) != len(answer_l):
            msg = msg + "Wrong size " + \
                        f"{len(output_l)} != {len(answer_l)}.\n"

        prev = (None, None)
        for o, a in zip(output_l, answer_l):
            if o != a:
                msg = msg + f"Wrong path: {prev}->{o}"
            prev = o

        super().__init__(msg)


class WrongAnswerTask3(Exception):
    def __init__(self, output: int, answer: int):
        super().__init__(f"Wrong answer, {output} != {answer}")


class WrongAnswerTask4(Exception):
    def __init__(self, ans, out):
        super().__init__(f"Wrong answer:\n"
                         f"Expected edges but missing: {ans}\n"
                         f"Wrong edges: {out}\n")
