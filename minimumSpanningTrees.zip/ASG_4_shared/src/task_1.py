#!/usr/bin/env python3
'''
Std. no: 2778835
'''
#
# from typing import List, Tuple, Dict, Callable
# from math import sqrt
#
# class Graph:
#     def __init__(self):
#         self.nodes: Dict[Tuple[int, int], int] = {}
#         self.edges: Dict[Tuple[int, int], Dict[Tuple[int, int], int]] = {}
#         self.max: List[Tuple[Tuple[int, int], int]] = [((0, 0), -1), ((0, 0), -1)]
#
#     def add_node(self, node_id: Tuple[int, int], weight: int):
#         self.nodes[node_id] = weight
#         if weight > self.max[0][1]:
#             self.max[1] = self.max[0]
#             self.max[0] = (node_id, weight)
#         elif weight > self.max[1][1]:
#             self.max[1] = (node_id, weight)
#
#     def add_edge(self, source_id: Tuple[int, int], end_id: Tuple[int, int], cost: int):
#         if source_id not in self.edges:
#             self.edges[source_id] = {}
#         if end_id not in self.edges:
#             self.edges[end_id] = {}
#         self.edges[source_id][end_id] = cost
#         self.edges[end_id][source_id] = cost
#
#     def astar_shortest_path(self, source_id: Tuple[int, int], end_id: Tuple[int, int], heuristic: Callable):
#         if source_id not in self.nodes or end_id not in self.nodes:
#             return None
#
#         open_set = [(source_id, 0, heuristic(source_id, end_id))]
#         closed_set = set()
#         came_from = {}
#
#         while open_set:
#             current, g_score, f_score = min(open_set, key=lambda x: x[2])
#
#             if current == end_id:
#                 path = [current]
#                 while current in came_from:
#                     current = came_from[current]
#                     path.insert(0, current)
#                 return path
#
#             open_set.remove((current, g_score, f_score))
#             closed_set.add(current)
#
#             for neighbor in self.edges[current]:
#                 if neighbor in closed_set:
#                     continue
#
#                 tentative_g_score = g_score + self.edges[current][neighbor]
#
#                 if (neighbor, g_score, f_score) not in open_set or tentative_g_score < g_score:
#                     came_from[neighbor] = current
#                     g_score = tentative_g_score
#                     f_score = g_score + heuristic(neighbor, end_id)
#                     open_set.append((neighbor, g_score, f_score))
#
#         return None
#
# def heuristic(u: Tuple[int, int], v: Tuple[int, int]):
#     x1, y1 = u
#     x2, y2 = v
#     return sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
#
# def build_Graph(nodes_l: List[Tuple[Tuple[int, int], int]], edges_l: List[Tuple[Tuple[int, int], Tuple[int, int], int]]):
#     G = Graph()
#     for node, w in nodes_l:
#         G.add_node(node, weight=w)
#     for node1, node2, c in edges_l:
#         G.add_edge(node1, node2, cost=c)
#     return G
#
# def shortest_path(nodes_l: List[Tuple[Tuple[int, int], int]], edges_l: List[Tuple[Tuple[int, int], Tuple[int, int], int]]) -> List[Tuple[int, int]]:
#     G = build_Graph(nodes_l, edges_l)
#     source_id = G.max[0][0]
#     end_id = G.max[1][0]
#     s_path = G.astar_shortest_path(source_id, end_id, heuristic)
#     return s_path
#
# # nodes_l = [((0, 0), 5), ((1, 1), 7), ((2, 2), 3), ((3, 3), 8)]
# # edges_l = [((0, 0), (1, 1), 2), ((1, 1), (2, 2), 4), ((2, 2), (3, 3), 3)]
# #
# # result = shortest_path(nodes_l, edges_l)
# # print(result)



from typing import List, Tuple, Dict, Callable
from math import sqrt

class Graph:
    def __init__(self):
        self.nodes: Dict[Tuple[int, int], int] = {}
        self.edges: Dict[Tuple[int, int], Dict[Tuple[int, int], int]] = {}
        self.max: List[Tuple[Tuple[int, int], int]] = [((0, 0), -1), ((0, 0), -1)]

    def add_node(self, node_id: Tuple[int, int], weight: int):
        self.nodes[node_id] = weight
        if weight > self.max[0][1]:
            self.max[1] = self.max[0]
            self.max[0] = (node_id, weight)
        elif weight > self.max[1][1]:
            self.max[1] = (node_id, weight)

    def add_edge(self, source_id: Tuple[int, int], end_id: Tuple[int, int], cost: int):
        if source_id not in self.edges:
            self.edges[source_id] = {}
        if end_id not in self.edges:
            self.edges[end_id] = {}
        self.edges[source_id][end_id] = cost
        self.edges[end_id][source_id] = cost

    def astar_shortest_path(self, source_id: Tuple[int, int], end_id: Tuple[int, int], heuristic: Callable):
        if source_id not in self.nodes or end_id not in self.nodes:
            return None

        open_set = [(source_id, 0, heuristic(source_id, end_id))]
        closed_set = set()
        came_from = {}

        while open_set:
            current, g_score, f_score = min(open_set, key=lambda x: x[2])

            if current == end_id:
                path = [current]
                while current in came_from:
                    current = came_from[current]
                    path.insert(0, current)
                return path

            open_set.remove((current, g_score, f_score))
            closed_set.add(current)

            for neighbor in self.edges[current]:
                if neighbor in closed_set:
                    continue

                tentative_g_score = g_score + self.edges[current][neighbor]

                if (neighbor, g_score, f_score) not in open_set or tentative_g_score < g_score:
                    came_from[neighbor] = current
                    g_score = tentative_g_score
                    f_score = g_score + heuristic(neighbor, end_id)
                    open_set.append((neighbor, g_score, f_score))

        return None

def heuristic(u: Tuple[int, int], v: Tuple[int, int]):
    x1, y1 = u
    x2, y2 = v
    return sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)  # Euclidean distance

def build_Graph(nodes_l: List[Tuple[Tuple[int, int], int]],
                edges_l: List[Tuple[Tuple[int, int], Tuple[int, int], int]]):
    G = Graph()
    for node, w in nodes_l:
        G.add_node(node, weight=w)
    for node1, node2, c in edges_l:
        G.add_edge(node1, node2, cost=c)
    return G


def shortest_path(nodes_l: List[Tuple[Tuple[int, int], int]], edges_l: List[Tuple[Tuple[int, int], Tuple[int, int], int]]) -> List[Tuple[int, int]]:
    G = build_Graph(nodes_l, edges_l)
    source_id = G.max[0][0]
    end_id = G.max[1][0]

    def custom_heuristic(node_id, end_id):
        return heuristic(node_id, end_id)

    s_path = G.astar_shortest_path(source_id, end_id, custom_heuristic)
    return s_path

# Example input data
nodes_l = [((0, 0), 5), ((1, 1), 7), ((2, 2), 3), ((3, 3), 8)]
edges_l = [((0, 0), (1, 1), 2), ((1, 1), (2, 2), 4), ((2, 2), (3, 3), 3)]

result = shortest_path(nodes_l, edges_l)
print(result)

