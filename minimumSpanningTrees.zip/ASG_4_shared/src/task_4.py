#!/usr/bin/env python3
'''
Std. no: 2778835
'''

from typing import List, Tuple


class UnionFind:
    def __init__(self, size):
        self.parent = [i for i in range(size)]
        self.rank = [0] * size

    def find(self, x):
        if x != self.parent[x]:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        root_x = self.find(x)
        root_y = self.find(y)
        if root_x != root_y:
            if self.rank[root_x] > self.rank[root_y]:
                self.parent[root_y] = root_x
            else:
                self.parent[root_x] = root_y
                if self.rank[root_x] == self.rank[root_y]:
                    self.rank[root_y] += 1


def min_spanning_tree(nodes_l: List[int],
                      edges_l: List[Tuple[int, int, int]]
                      ) -> List[Tuple[int, int, int]]:
    edges_l.sort(key=lambda x: x[2])  # Sort edges by cost

    size = len(nodes_l)
    mst = []
    union_find = UnionFind(size)

    for edge in edges_l:
        u, v, cost = edge
        if union_find.find(u) != union_find.find(v):
            mst.append(edge)
            union_find.union(u, v)

    return mst

# Example input data
nodes_l = [0, 1, 2, 3]
edges_l = [(0, 1, 2), (1, 2, 4), (2, 3, 3)]

# Find the minimum spanning tree
minimum_spanning_tree = min_spanning_tree(nodes_l, edges_l)
print(minimum_spanning_tree)

