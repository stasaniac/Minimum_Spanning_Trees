#!/usr/bin/env python3
'''
Std. no: 2778835
'''

from typing import List, Tuple, Dict

class Graph:
    def __init__(self):
        self.nodes: List[int] = []
        self.edges: Dict[int, Dict[int, int]] = {}

    def add_node(self, node_id: int):
        if node_id not in self.nodes:
            self.nodes.append(node_id)
            self.edges[node_id] = {}

    def add_edge(self, source_id: int, end_id: int, cost: int):
        if source_id not in self.edges:
            self.edges[source_id] = {}
        if end_id not in self.edges:
            self.edges[end_id] = {}
        self.edges[source_id][end_id] = cost
        self.edges[end_id][source_id] = cost

def build_Graph(nodes_l: List[int], edges_l: List[Tuple[int, int, int]]):
    G = Graph()
    for node in nodes_l:
        G.add_node(node)
    for node1, node2, c in edges_l:
        G.add_edge(node1, node2, cost=c)
    return G

def most_central(nodes_l: List[int], edges_l: List[Tuple[int, int, int]]) -> int:
    G = build_Graph(nodes_l, edges_l)

    centrality = {}
    for node in G.nodes:
        centrality[node] = 0

    for node in G.nodes:
        for source in G.nodes:
            for end in G.nodes:
                if source != end and source != node and end != node:
                    # Implement shortest path calculation here
                    # paths_source_end = len(G.astar_shortest_path(source, end))
                    # paths_source_end_node = len(G.astar_shortest_path(source, end, node))
                    pass

                    # Update centrality based on shortest paths
                    # centrality[node] += (paths_source_end_node / paths_source_end)

    central_node = max(centrality, key=centrality.get)
    return central_node

# Example input data
nodes_l = [0, 1, 2, 3]
edges_l = [(0, 1, 2), (1, 2, 4), (2, 3, 3)]

# Find the most central node
central_node = most_central(nodes_l, edges_l)
print(central_node)

