#!/usr/bin/env python3

from typing import Callable, List, Tuple
import time
import pytest
import logging
from os import path

import cg_pytest_reporter as cg_pytest

from src import task_1, task_2, task_3, task_4
import error

logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger('logger')
root_dir = path.dirname(path.abspath(__file__))


@pytest.mark.task_1
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 2')
@cg_pytest.suite_weight(0.5)
class TestTask1:
    '''
    TASK-1 worth 2 points
    '''
    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[
                [List[Tuple[Tuple[int, int], int]],
                 List[Tuple[Tuple[int, int], Tuple[int, int], int]]],
                List[Tuple[int, int]]]):

        answer = open(f"{root_dir}/{testcase}.ans", "r").readline().rstrip()
        tmp_ans = answer.replace("(", "").replace(")", "").split()
        answer_l: List[Tuple[int, int]] = []
        for n in tmp_ans:
            x, y = n.split(',')
            answer_l.append((int(x), int(y)))

        input_file = open(f"{root_dir}/{testcase}.in", "r")
        data: str = input_file.read()
        nodes, edges = data.split('\n')
        nodes_sl: List[str] = nodes.split('; ')
        nodes_l: List[Tuple[Tuple[int, int], int]] = []
        for n in nodes_sl:
            x, y, w = n.split(', ')
            nodes_l.append(((int(x), int(y)), int(w)))

        edges_sl: List[str] = edges.split('; ')
        edges_l: List[Tuple[Tuple[int, int], Tuple[int, int], int]] = []
        for e in edges_sl:
            x1, y1, x2, y2, w = e.split(', ')
            edges_l.append(((int(x1), int(y1)), (int(x2), int(y2)), int(w)))

        start_time = time.time()
        output_l: List[Tuple[int, int]] = func(nodes_l, edges_l)
        end_time = time.time()

        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.debug(f'Call to {func.__name__} took {exec_time}s')

        if not output_l:
            raise error.NoOutput()

        if isinstance(output_l, list) and all(isinstance(x, tuple)
                                              for x in output_l):
            if not all(isinstance(x, int) and isinstance(y, int)
                       for x, y in output_l):
                raise error.WrongType(List[Tuple[int, int]])
        else:
            raise error.WrongType(List[Tuple[int, int]])

        # Take care of case (u, v) != (v, u)
        if output_l != answer_l:
            raise error.WrongAnswerTask1(output_l, answer_l)

    @cg_pytest.description('Grid size: 10x10, path length: 9')
    def test_1(self):
        self.run("testcases/task_1/10_10_4-0_4-9", 20,
                 task_1.shortest_path)

    @cg_pytest.description('Grid size: 10x100, path length: 99')
    def test_2(self):
        self.run("testcases/task_1/10_100_4-99_4-0", 20,
                 task_1.shortest_path)

    @cg_pytest.description('Grid size: 1000x10, path length: 978')
    def test_3(self):
        self.run("testcases/task_1/1000_10_12-4_990-4", 20,
                 task_1.shortest_path)

    @cg_pytest.description('Grid size: 4x5000, path length: 4999')
    def test_4(self):
        self.run("testcases/task_1/4_5000_2-0_2-4999", 20,
                 task_1.shortest_path)


@pytest.mark.task_2
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 2')
@cg_pytest.suite_weight(0.25)
class TestTask2:
    '''
    TASK-2 worth 1 point
    '''
    @cg_pytest.description('Grid size: 10x10, path length: 8')
    def test_1(self):
        TestTask1.run("testcases/task_2/10_10_1-0_9-8", 20,
                      task_2.shortest_path)

    @cg_pytest.description('Grid size: 10x10, path length: 9')
    def test_2(self):
        TestTask1.run("testcases/task_2/10_10_9-9_0-0", 20,
                      task_2.shortest_path)

    @cg_pytest.description('Grid size: 100x100, path length: 99')
    def test_3(self):
        TestTask1.run("testcases/task_2/100_100_99-99_0-0", 20,
                      task_2.shortest_path)

    @cg_pytest.description('Grid size: 500x500, path length: 99')
    def test_4(self):
        TestTask1.run("testcases/task_2/500_500_99-99_0-0", 20,
                      task_2.shortest_path)


@pytest.mark.task_3
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 3')
@cg_pytest.suite_weight(0.75)
class TestTask3:
    '''
    TASK-3 worth 3 points
    '''
    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[[List[int],
                            List[Tuple[int, int, int]]], int]):

        input_file = open(f"{root_dir}/{testcase}.in", "r")
        answer = \
            int(open(f"{root_dir}/{testcase}.ans", "r").readline().rstrip())

        data: str = input_file.read()
        nodes, edges = data.split('\n')
        nodes_sl: List[str] = nodes.split('; ')
        nodes_l: List[int] = [int(n) for n in nodes_sl]

        edges_sl: List[str] = edges.split('; ')
        edges_l: List[Tuple[int, int, int]] = []
        for e in edges_sl:
            n1, n2, w = e.split(', ')
            edges_l.append((int(n1), int(n2), int(w)))

        start_time = time.time()
        output: int = func(nodes_l, edges_l)
        end_time = time.time()

        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.debug(f'Call to {func.__name__} took {exec_time}s')

        if output is None:
            raise error.NoOutput()

        if not isinstance(output, int):
            raise error.WrongType(int)

        if output != answer:
            raise error.WrongAnswerTask3(output, answer)

    @cg_pytest.description('Small example 3 nodes 2 edges')
    def test_1(self):
        self.run("testcases/task_3/3_2", 20,
                 task_3.most_central)

    @cg_pytest.description('100 nodes 99 edges')
    def test_2(self):
        self.run("testcases/task_3/100_99", 20,
                 task_3.most_central)

    @cg_pytest.description('200 nodes 199 edges')
    def test_3(self):
        self.run("testcases/task_3/200_199", 20,
                 task_3.most_central)

    @cg_pytest.description('400 nodes 399 edges')
    def test_4(self):
        self.run("testcases/task_3/400_399", 20,
                 task_3.most_central)


@pytest.mark.task_4
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 4')
@cg_pytest.suite_weight(1)
class TestTask4:
    '''
    TASK-4 worth 4 points
    '''
    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[[List[int],
                            List[Tuple[int, int, int]]],
                           List[Tuple[int, int, int]]]):

        input_file = open(f"{root_dir}/{testcase}.in", "r")
        answer_file = open(f"{root_dir}/{testcase}.ans", "r")

        # Create answer List
        answer: str = answer_file.read()
        answer_sl: List[str] = answer.split('; ')
        answer_l: List[Tuple[int, int, int]] = []
        for e in answer_sl:
            n1, n2, w = e.split(', ')
            answer_l.append((int(n1), int(n2), int(w)))

        data: str = input_file.read()
        nodes, edges = data.split('\n')

        # Create nodes
        nodes_sl: List[str] = nodes.split('; ')
        nodes_l: List[int] = [int(n) for n in nodes_sl]

        # Create edges
        edges_sl: List[str] = edges.split('; ')
        edges_l: List[Tuple[int, int, int]] = []
        for e in edges_sl:
            n1, n2, w = e.split(', ')
            edges_l.append((int(n1), int(n2), int(w)))

        start_time = time.time()
        output_l: List[Tuple[int, int, int]] = func(nodes_l, edges_l)
        end_time = time.time()

        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.debug(f'Call to {func.__name__} took {exec_time}s')

        if output_l is None:
            raise error.NoOutput()

        if isinstance(output_l, list) and all(isinstance(x, tuple)
                                              for x in output_l):
            if not all(isinstance(u, int) and isinstance(v, int)
                       and isinstance(c, int)
                       for u, v, c in output_l):
                raise error.WrongType(List[Tuple[int, int, int]])
        else:
            raise error.WrongType(List[Tuple[int, int, int]])

        # Convert lists to sets of tuples with sorted node IDs
        # Take care of case (u, v, c) != (v, u, c)
        ans_set = set(tuple(sorted(edge[:2])) + (edge[2],)
                      for edge in answer_l)
        out_set = set(tuple(sorted(edge[:2])) + (edge[2],)
                      for edge in output_l)

        tuples_only_in_out = out_set - ans_set
        tuples_only_in_ans = ans_set - out_set

        # Also take care of case (u, v, c)!=(v, u, c)
        if tuples_only_in_ans:
            raise error.WrongAnswerTask4(tuples_only_in_ans,
                                         tuples_only_in_out)

    @cg_pytest.description('10 nodes')
    def test_1(self):
        self.run("testcases/task_4/10", 20,
                 task_4.min_spanning_tree)

    @cg_pytest.description('100 nodes')
    def test_2(self):
        self.run("testcases/task_4/100", 20,
                 task_4.min_spanning_tree)

    @cg_pytest.description('500 nodes')
    def test_3(self):
        self.run("testcases/task_4/500", 20,
                 task_4.min_spanning_tree)

    @cg_pytest.description('1000 nodes')
    def test_4(self):
        self.run("testcases/task_4/1000", 20,
                 task_4.min_spanning_tree)
